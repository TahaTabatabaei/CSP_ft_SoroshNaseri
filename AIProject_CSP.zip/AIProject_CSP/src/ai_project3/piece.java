/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ai_project3;

/**
 *
 * @author Patric
 */
public class piece {
    
   public String value ;
   
   public int  Variable  ; // whichVarInArray
   
}
